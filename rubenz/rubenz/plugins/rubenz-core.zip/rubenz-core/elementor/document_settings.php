<?php

/**
 * Add new controls after end of "General Settings"
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'arts_add_elementor_document_settings_after_controls' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'arts_add_elementor_document_settings_after_controls' );

function arts_add_elementor_document_settings_after_controls( \Elementor\Core\DocumentTypes\PageBase $page ) {

	$post_id           = get_the_ID();
	$post_type         = get_post_type( $post_id );
	$is_portfolio_item = $post_type == 'arts_portfolio_item';

	$page->start_controls_section(
		'page_masthead_section',
		array(
			'label' => esc_html__( 'Page Masthead', 'rubenz' ),
			'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
		)
	);

	/**
	 * Page Masthead Layout
	 */
	$page->add_control(
		'page_masthead_layout',
		array(
			'label'   => esc_html__( 'Layout', 'rubenz' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => array(
				'content_top'              => esc_html__( 'Content Top & Image Bottom', 'rubenz' ),
				'halfscreen_content_left'  => esc_html__( 'Halfscreen: Content Left & Image Right', 'rubenz' ),
				'halfscreen_content_right' => esc_html__( 'Halfscreen: Content Right & Image Left', 'rubenz' ),
				'fullscreen'               => esc_html__( 'Fullscreen', 'rubenz' ),
			),
			'default' => 'content_top',
		)
	);

	$page->add_control(
		'page_masthead_alignment',
		array(
			'label'   => esc_html__( 'Content Alignment', 'rubenz' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => array(
				'text-left'   => array(
					'title' => esc_html__( 'Left', 'rubenz' ),
					'icon'  => 'eicon-text-align-left',
				),
				'text-center' => array(
					'title' => esc_html__( 'Center', 'rubenz' ),
					'icon'  => 'eicon-text-align-center',
				),
				'text-right'  => array(
					'title' => esc_html__( 'Right', 'rubenz' ),
					'icon'  => 'eicon-text-align-right',
				),
			),
			'default' => 'text-left',
			'toggle'  => false,
		)
	);

	$page->add_control(
		'heading_image',
		array(
			'label'     => esc_html__( 'Background Image', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
		)
	);

	/**
	 * Page Masthead Overlay Opacity
	 */
	$page->add_control(
		'page_masthead_overlay_opacity',
		array(
			'label'     => esc_html__( 'Image Overlay Opacity', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'default'   => array(
				'size' => .6,
			),
			'range'     => array(
				'px' => array(
					'max'  => 1,
					'step' => 0.01,
				),
			),
			'selectors' => array(
				'{{WRAPPER}} .section-masthead__overlay' => 'opacity: {{SIZE}};',
			),
			'condition' => array(
				'page_masthead_layout' => 'fullscreen',
			),
		)
	);

	/**
	 * Min Height
	 */
	$page->add_responsive_control(
		'page_masthead_image_height',
		array(
			'label'           => esc_html__( 'Image Height', 'rubenz' ),
			'type'            => \Elementor\Controls_Manager::SLIDER,
			'desktop_default' => array(
				'size' => 900,
				'unit' => 'px',
			),
			'tablet_default'  => array(
				'size' => 70,
				'unit' => 'vh',
			),
			'mobile_default'  => array(
				'size' => 50,
				'unit' => 'vh',
			),
			'range'           => array(
				'px' => array(
					'min' => 0,
					'max' => 1440,
				),
				'vh' => array(
					'min' => 0,
					'max' => 100,
				),
			),
			'size_units'      => array( 'px', 'vh' ),
			'selectors'       => array(
				'{{WRAPPER}} .section-masthead__background' => 'height: 1px; min-height: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .section-masthead__background:after' => 'content: ""; min-height: inherit;', // Hack for IE11
			),
			'condition'       => array(
				'post_featured_image!' => array(
					'id'  => '',
					'url' => '',
				),
				'page_masthead_layout' => 'content_top',
			),
		)
	);

	$page->add_control(
		'page_masthead_image_layout',
		array(
			'label'     => esc_html__( 'Image Alignment', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::CHOOSE,
			'options'   => array(
				'section'                   => array(
					'title' => esc_html__( 'Fullwidth', 'rubenz' ),
					'icon'  => 'eicon-h-align-stretch',
				),
				'section_w-container-left'  => array(
					'title' => esc_html__( 'Left', 'rubenz' ),
					'icon'  => 'eicon-h-align-left',
				),
				'container'                 => array(
					'title' => esc_html__( 'Center', 'rubenz' ),
					'icon'  => 'eicon-h-align-center',
				),
				'section_w-container-right' => array(
					'title' => esc_html__( 'Right', 'rubenz' ),
					'icon'  => 'eicon-h-align-right',
				),
			),
			'default'   => 'section',
			'condition' => array(
				'page_masthead_layout' => 'content_top',
			),
			'toggle'    => false,
		)
	);

	/**
	 * Image Parallax
	 */
	$page->add_control(
		'page_masthead_image_parallax',
		array(
			'label'     => esc_html__( 'Enable Parallax', 'Elementor Widget', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SWITCHER,
			'default'   => 'yes',
			'condition' => array(
				'post_featured_image!' => array(
					'id'  => '',
					'url' => '',
				),
			),
		)
	);

	/**
	 * Image Parallax Speed
	 */
	$page->add_control(
		'page_masthead_image_parallax_speed',
		array(
			'label'     => esc_html__( 'Parallax Speed', 'Elementor Widget', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array(
				'factor' => array(
					'min'  => -0.5,
					'max'  => 0.5,
					'step' => 0.01,
				),
			),
			'default'   => array(
				'unit' => 'factor',
				'size' => 0.1,
			),
			'condition' => array(
				'page_masthead_image_parallax' => 'yes',
				'post_featured_image!'         => array(
					'id'  => '',
					'url' => '',
				),
			),
		)
	);

	$page->end_controls_section();

	$page->start_controls_section(
		'footer_section',
		array(
			'label' => esc_html__( 'Page Footer', 'rubenz' ),
			'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
		)
	);

	/**
	 * Override Footer
	 */
	$page->add_control(
		'page_footer_settings',
		array(
			'label'       => esc_html__( 'Override Page Footer Settings', 'Elementor Widget Section', 'rubenz' ),
			'description' => esc_html__( 'Use custom footer settings for this page instead of global customizer settings', 'Elementor Widget Section', 'rubenz' ),
			'type'        => \Elementor\Controls_Manager::SWITCHER,
			'default'     => $is_portfolio_item ? 'yes' : '',
		)
	);

	/**
	 * Footer Hide
	 */
	$page->add_control(
		'page_footer_hide',
		array(
			'label'     => esc_html__( 'Remove Footer from this Page', 'Elementor Widget Section', 'rubenz' ),
			'type'      => \Elementor\Controls_Manager::SWITCHER,
			'default'   => $is_portfolio_item ? 'yes' : '',
			'condition' => array(
				'page_footer_settings' => 'yes',
			),
		)
	);

	$page->end_controls_section();

}

/**
 * Add new controls in the end of "General Settings"
 */
add_action( 'elementor/element/wp-page/document_settings/before_section_end', 'arts_add_elementor_document_settings_before_end_controls' );
add_action( 'elementor/element/wp-post/document_settings/before_section_end', 'arts_add_elementor_document_settings_before_end_controls' );

function arts_add_elementor_document_settings_before_end_controls( \Elementor\Core\DocumentTypes\PageBase $page ) {

	/**
	 * Page Color Theme
	 */
	$page->add_control(
		'page_main_color_theme',
		array(
			'label'   => esc_html__( 'Page Color Theme', 'rubenz' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => array(
				'bg-white'          => esc_html__( 'Pure White', 'rubenz' ),
				'bg-light-grey'     => esc_html__( 'Light 1', 'rubenz' ),
				'bg-light'          => esc_html__( 'Light 2', 'rubenz' ),
				'bg-blue-grey'      => esc_html__( 'Blue Grey 1', 'rubenz' ),
				'bg-blue-grey-dark' => esc_html__( 'Blue Grey 2', 'rubenz' ),
				'bg-dark'           => esc_html__( 'Dark 1', 'rubenz' ),
				'bg-dark-2'         => esc_html__( 'Dark 2', 'rubenz' ),
				'bg-black'          => esc_html__( 'Dark 3', 'rubenz' ),
			),
			'default' => 'bg-blue-grey',
		)
	);

}

/**
 * Page Portfolio Navigation in Elementor Document Settings
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'arts_add_elementor_document_settings_page_ajax' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'arts_add_elementor_document_settings_page_ajax' );

function arts_add_elementor_document_settings_page_ajax( \Elementor\Core\DocumentTypes\PageBase $page ) {

	$page->start_controls_section(
		'page_ajax_section',
		array(
			'label' => esc_html__( 'Page AJAX Transition', 'rubenz' ),
			'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
		)
	);

	$page->add_control(
		'page_ajax_to_enabled',
		array(
			'label'   => sprintf(
				'%1s <strong>%2s</strong> %3s',
				esc_html__( 'Enable AJAX Transition', 'rubenz' ),
				esc_html__( 'TO', 'rubenz' ),
				esc_html__( 'this Page', 'rubenz' )
			),
			'type'    => \Elementor\Controls_Manager::SWITCHER,
			'default' => 'yes',
		)
	);

	$page->add_control(
		'page_ajax_to_disabled_notice',
		array(
			'type'            => \Elementor\Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'This page will interrupt an active AJAX transition and perform a hard refresh in browser.', 'rubenz' ),
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			'condition'       => array(
				'page_ajax_to_enabled' => '',
			),
		)
	);

	$page->add_control(
		'page_ajax_from_enabled',
		array(
			'label'   => sprintf(
				'%1s <strong>%2s</strong> %3s',
				esc_html__( 'Enable AJAX Transition', 'rubenz' ),
				esc_html__( 'FROM', 'rubenz' ),
				esc_html__( 'this Page', 'rubenz' )
			),
			'type'    => \Elementor\Controls_Manager::SWITCHER,
			'default' => 'yes',
		)
	);

	$page->add_control(
		'page_ajax_from_disabled_notice',
		array(
			'type'            => \Elementor\Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'All the links on this page will perform a hard refresh in browser.', 'rubenz' ),
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			'condition'       => array(
				'page_ajax_from_enabled' => '',
			),
		)
	);

	$page->end_controls_section();

}
