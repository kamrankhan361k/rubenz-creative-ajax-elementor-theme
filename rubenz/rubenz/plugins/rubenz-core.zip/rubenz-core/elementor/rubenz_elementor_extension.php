<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Rubenz Elementor Extension
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Rubenz_Elementor_Extension {

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '3.5.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.6';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Rubenz_Elementor_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Rubenz_Elementor_Extension An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		add_action( 'plugins_loaded', array( $this, 'init' ) );

	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_missing_main_plugin' ) );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );
			return;
		}

		// Add Plugin actions
		add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ) );
		add_action( 'elementor/widgets/register', array( $this, 'init_widgets' ) );

		// Add WPML String Translation Support
		if ( class_exists( 'SitePress' ) ) {
			add_action( 'init', array( $this, 'add_widgets_wpml_support' ) );
		}

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'rubenz' ),
			'<strong>' . esc_html__( 'Rubenz Elementor Extension', 'rubenz' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'rubenz' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'rubenz' ),
			'<strong>' . esc_html__( 'Rubenz Elementor Extension', 'rubenz' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'rubenz' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'rubenz' ),
			'<strong>' . esc_html__( 'Rubenz Elementor Extension', 'rubenz' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'rubenz' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-error is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Register Custom Widget Categories
	 *
	 * @return void
	 */
	public function add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'rubenz-static',
			array(
				'title' => esc_html__( 'Rubenz Static Widgets', 'rubenz' ),
				'icon'  => 'eicon-plug',
			)
		);

		$elements_manager->add_category(
			'rubenz-dynamic',
			array(
				'title' => esc_html__( 'Rubenz Dynamic Widgets', 'rubenz' ),
				'icon'  => 'eicon-sitemap',
			)
		);

	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function include_widgets_files() {

		// Custom Base Widget
		require_once __DIR__ . '/widgets/rubenz-widget-base.php';

		// Dynamic Widgets Require
		require_once __DIR__ . '/widgets/dynamic/portfolio-fullscreen-two-rows-slider.php';
		require_once __DIR__ . '/widgets/dynamic/portfolio-fullscreen-headings-slider.php';
		require_once __DIR__ . '/widgets/dynamic/portfolio-fullscreen-slider.php';
		require_once __DIR__ . '/widgets/dynamic/portfolio-masonry-grid.php';

		// Static Widgets Require
		require_once __DIR__ . '/widgets/static/call-to-action.php';
		require_once __DIR__ . '/widgets/static/counters.php';
		require_once __DIR__ . '/widgets/static/features-image.php';
		require_once __DIR__ . '/widgets/static/features-list.php';
		require_once __DIR__ . '/widgets/static/google-map.php';
		require_once __DIR__ . '/widgets/static/header-section.php';
		require_once __DIR__ . '/widgets/static/intro-text.php';
		require_once __DIR__ . '/widgets/static/lightbox-video.php';
		require_once __DIR__ . '/widgets/static/logo-description.php';
		require_once __DIR__ . '/widgets/static/masonry-grid.php';
		require_once __DIR__ . '/widgets/static/parallax-background.php';
		require_once __DIR__ . '/widgets/static/pricing-table.php';
		require_once __DIR__ . '/widgets/static/slider-images.php';
		require_once __DIR__ . '/widgets/static/slider-testimonials.php';
		require_once __DIR__ . '/widgets/static/team-member.php';

	}

	/**
	 * WPML compatibility classes
	 *
	 * Include files with WPML compatability classes
	 * for widgets with repeaters fields
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function include_wpml_files() {

		require_once __DIR__ . '/widgets/compatibility/wpml-counters.php';
		require_once __DIR__ . '/widgets/compatibility/wpml-features-image.php';
		require_once __DIR__ . '/widgets/compatibility/wpml-features-list.php';
		require_once __DIR__ . '/widgets/compatibility/wpml-google-map.php';
		require_once __DIR__ . '/widgets/compatibility/wpml-pricing-table.php';
		require_once __DIR__ . '/widgets/compatibility/wpml-slider-testimonials.php';

	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		$this->include_widgets_files();

		// Dynamic Widgets Init
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Portfolio_Fullscreen_Headings_Slider::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Portfolio_Fullscreen_Slider::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Portfolio_Fullscreen_Two_Rows_Slider::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Portfolio_Masonry_Grid::instance() );

		// Static Widgets Init
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Call_To_Action::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Counters::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Features_Image::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Features_List::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( new \Elementor\Rubenz_Widget_Google_Map() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Header_Section::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Intro_Text::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Lightbox_Video::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Logo_Description::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Masonry_Grid::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Parallax_Background::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Pricing_Table::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Slider_Images::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Slider_Testimonials::instance() );
		\Elementor\Plugin::instance()->widgets_manager->register( \Elementor\Rubenz_Widget_Team_Member::instance() );

	}

	public function add_widgets_wpml_support() {

		$this->include_wpml_files();
		$this->include_widgets_files();

		\Elementor\Rubenz_Widget_Portfolio_Fullscreen_Two_Rows_Slider::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Portfolio_Fullscreen_Slider::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Portfolio_Masonry_Grid::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Call_To_Action::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Counters::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Features_Image::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Features_List::instance()->add_wpml_support();

		$widget = new \Elementor\Rubenz_Widget_Google_Map();
		$widget->add_wpml_support();

		\Elementor\Rubenz_Widget_Header_Section::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Intro_Text::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Lightbox_Video::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Logo_Description::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Parallax_Background::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Pricing_Table::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Slider_Testimonials::instance()->add_wpml_support();
		\Elementor\Rubenz_Widget_Team_Member::instance()->add_wpml_support();

	}

}
Rubenz_Elementor_Extension::instance();
