<?php

class WPML_Rubenz_Elementor_Slider_Testimonials extends WPML_Elementor_Module_With_Items {
	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'testimonials';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return array( 'author', 'text' );
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'author':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Slider Testimonials', 'rubenz' ), esc_html__( 'Author', 'rubenz' ) );
			case 'text':
				return sprintf( '<strong>%1$s</strong><br>%2$s', esc_html__( 'Slider Testimonials', 'rubenz' ), esc_html__( 'Text', 'rubenz' ) );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'author':
				return 'LINE';
			case 'text':
				return 'AREA';

			default:
				return '';
		}
	}
}
