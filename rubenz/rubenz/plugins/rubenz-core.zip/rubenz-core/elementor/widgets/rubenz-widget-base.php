<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Base extends Widget_Base {
	protected static $_instance;

	public static function instance() {
		if ( is_null( static::$_instance ) ) {
			static::$_instance = new static();
		}

		return static::$_instance;
	}

	public function get_name() {}

	public function get_title() {}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	protected static $_posts, $_post_type;

	/**
	 * WordPress DB query for the posts
	 *
	 * @return void
	 */
	protected static function _get_posts() {

		// get class name in lowercase
		$class_name = ( new \ReflectionClass( static::class ) )->getShortName();
		$class_name = strtolower( $class_name );

		// filter to change current widget post type
		$args = apply_filters(
			'arts/elementor/' . $class_name . '/query_args',
			array(
				'post_type'      => static::$_post_type,
				'posts_per_page' => -1,
			)
		);

		$posts      = array();
		$taxonomies = array();
		$counter    = 0;

		$loop = new \WP_Query( $args );

		if ( $loop->have_posts() ) {

			while ( $loop->have_posts() ) {

				$loop->the_post();

				$posts[ $counter ]['id']               = get_the_ID();
				$posts[ $counter ]['title']            = get_the_title();
				$posts[ $counter ]['permalink']        = get_the_permalink();
				$posts[ $counter ]['image_id']         = get_post_thumbnail_id();
				$posts[ $counter ]['description']      = arts_get_field( 'text', $posts[ $counter ]['id'] );
				$post_categories                       = get_the_terms( $posts[ $counter ]['id'], 'arts_portfolio_category' );
				$posts[ $counter ]['categories']       = $post_categories;
				$posts[ $counter ]['categories_names'] = array();
				$posts[ $counter ]['categories_slugs'] = array();

				if ( is_array( $post_categories ) ) {
					foreach ( $post_categories as $item ) {

						$arr = array(
							'slug' => $item->slug,
							'name' => $item->name,
						);

						array_push( $posts[ $counter ]['categories_names'], $item->name );
						array_push( $posts[ $counter ]['categories_slugs'], $item->slug );

						// don't add the same item multiple times
						if ( ! in_array( $arr, $taxonomies ) ) {
							array_push( $taxonomies, $arr );
						}
					}
				}

				$counter++;

			}

			wp_reset_postdata();

		}

		static::$_posts = $posts;
	}

	/**
	 * Get all posts by type
	 *
	 * @return array
	 */
	public function get_posts() {
		if ( is_null( static::$_posts ) ) {
			static::_get_posts();
		}

		return static::$_posts;
	}

	/**
	 * Filter out disabled posts
	 *
	 * @return array
	 */
	public function get_posts_to_display() {
		$posts    = $this->get_posts();
		$settings = $this->get_settings_for_display();

		// limit posts amount
		if ( $settings['posts_amount']['size'] > 0 ) {
			array_splice( $posts, $settings['posts_amount']['size'] );
		}

		// only "enabled" posts
		$posts = array_filter(
			$posts,
			function( $item ) {
				$settings = $this->get_settings_for_display();
				return ( array_key_exists( 'enabled' . $item['id'], $settings ) ) && ( $settings[ 'enabled' . $item['id'] ] );
			}
		);

		return $posts;
	}

	/**
	 * Helper function: print HTML tag
	 *
	 * @param string $settings_tag_key
	 * @return void
	 */
	public function print_html_tag( $settings_tag_key ) {
		$html_tag = $this->get_settings( esc_attr( $settings_tag_key ) );

		// fallback
		if ( empty( $html_tag ) ) {
			$html_tag = 'div';
		}

		echo $html_tag;
	}
}
