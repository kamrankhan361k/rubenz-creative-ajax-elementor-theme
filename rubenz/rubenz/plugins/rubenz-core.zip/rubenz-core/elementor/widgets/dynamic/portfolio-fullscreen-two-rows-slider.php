<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Portfolio_Fullscreen_Two_Rows_Slider extends Rubenz_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_portfolio_item';

	public function get_name() {
		return 'rubenz-widget-portfolio-fullscreen-two-rows-slider';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Fullscreen Two Rows Slider', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'rubenz-dynamic' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'label_normal',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Helper Label Normal', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'label_hover',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Helper Label Hover', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$posts     = $this->get_posts();
		$post_type = self::$_post_type;

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'rubenz' )
					),
					'type'       => Controls_Manager::RAW_HTML,
					'separator'  => 'before',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Enabled', 'rubenz' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

		}

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'rubenz' ),
					esc_html__( 'You can edit or re-order your posts', 'rubenz' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'rubenz' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Button', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'label_normal',
			array(
				'label'   => esc_html__( 'Title Normal', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Scroll / Drag', 'rubenz' ),
			)
		);

		$this->add_control(
			'label_hover',
			array(
				'label'   => esc_html__( 'Title Hover', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => esc_html__( 'Explore Project', 'rubenz' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Posts', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'   => esc_html__( 'Number of Posts to Display (0 for all)', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 0,
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'transitions_section',
			array(
				'label' => esc_html__( 'Transitions', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_transition',
			array(
				'label'   => esc_html__( 'Enable AJAX Image Transition', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_section',
			array(
				'label' => esc_html__( 'Slider', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);
		$this->add_control(
			'enable_mousewheel_control',
			array(
				'label'   => esc_html__( 'Mousewheel Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'mousewheel_target',
			array(
				'label'     => esc_html__( 'Mousewheel Events Target', 'rubenz' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '.page-wrapper',
				'options'   => array(
					'.page-wrapper' => esc_html__( 'Page Wrapper', 'rubenz' ),
					'container'     => esc_html__( 'Container', 'rubenz' ),
				),
				'condition' => array(
					'enable_mousewheel_control' => 'yes',
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts_to_display();
		$counter  = 0;

		$this->add_render_attribute(
			'slider',
			array(
				'class' => array( 'slider', 'slider-text', 'js-slider-text' ),
			)
		);

		if ( $settings['enable_mousewheel_control'] ) {
			$this->add_render_attribute(
				'slider',
				array(
					'data-mousewheel-enabled' => 'true',
					'data-mousewheel-target'  => $settings['mousewheel_target'],
				)
			);
		}

		$posts_reverse = array_reverse( $posts );
		$amount        = count( $posts );
		$amount++;

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div class="section section-fullscreen-slider section-text-slider section-fullheight" data-os-animation="data-os-animation">
				<div class="section-fullheight__inner section-fullscreen-slider__inner">
					<div <?php echo $this->get_render_attribute_string( 'slider' ); ?>>
						<div class="swiper swiper-container slider-text__upper js-slider-text__upper">
							<div class="swiper-wrapper">
								<?php foreach ( $posts as $index => $item ) : ?>
									<?php
									$attrs_link = '';
									$index++;
									$counter++;
									if ( $counter < 10 ) {
										$counter_string = '00' . $counter;
									} else {
										$counter_string = '0' . $counter;
									}

									if ( ! empty( $item['image_id'] ) && $settings['enable_transition'] ) {
										$attrs_link = 'data-pjax-link=fullscreenSlider';
									}
									?>
									<div class="swiper-slide slider-text__slide">
										<a class="slider-text__link" href="<?php echo esc_url( $item['permalink'] ); ?>" <?php echo esc_attr( $attrs_link ); ?> data-slide-id="<?php echo esc_attr( $item['id'] ); ?>">
											<div class="slider-text__line"></div>
											<header class="slider-text__header">
												<div class="slider-text__counter split-chars"><?php echo $counter_string; ?></div>
												<h2 class="split-chars"><?php echo $item['title']; ?></h2>
											</header>
										</a>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
						<!-- - upper line-->
						<div class="swiper swiper-container slider-text__lower js-slider-text__lower" dir="rtl">
							<div class="swiper-wrapper">
								<?php foreach ( $posts_reverse as $index => $item ) : ?>
									<?php
									$attrs_link = '';
									$amount--;
									if ( $counter < 10 ) {
										$counter_string = '00' . $counter;
									} else {
										$counter_string = '0' . $counter;
									}
									$counter--;

									if ( ! empty( $item['image_id'] ) ) {
										$attrs_link = 'data-pjax-link=fullscreenSlider';
									}
									?>
									<div class="swiper-slide slider-text__slide" dir="ltr">
										<a class="slider-text__link" href="<?php echo esc_url( $item['permalink'] ); ?>" <?php echo esc_attr( $attrs_link ); ?> data-slide-id="<?php echo esc_attr( $item['id'] ); ?>">
											<div class="slider-text__line"></div>
											<header class="slider-text__header">
												<div class="slider-text__counter split-chars"><?php echo $counter_string; ?></div>
												<h2 class="split-chars"><?php echo $item['title']; ?></h2>
											</header>
										</a>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
						<!-- - lower line -->
						<?php if ( ! empty( $settings['label_normal'] ) && ! empty( $settings['label_hover'] ) ) : ?>
							<div class="slider-text__helper">
								<div class="slider-text__helper__inner">
									<div class="slider-text__helper-icon slider-text__helper-icon_left material-icons">keyboard_arrow_left</div>
									<div class="slider-text__helper-label-normal split-chars"><?php echo $settings['label_normal']; ?></div>
									<div class="slider-text__helper-label-view split-chars"><?php echo $settings['label_hover']; ?></div>
									<div class="slider-text__helper-icon slider-text__helper-icon_right material-icons">keyboard_arrow_right</div>
								</div>
							</div>
							<!-- - helper -->
						<?php endif; ?>
						<div class="slider__backgrounds">
							<?php foreach ( $posts as $item ) : ?>
								<?php if ( ! empty( $item['image_id'] ) ) : ?>
									<?php
										arts_the_lazy_image(
											array(
												'id'    => $item['image_id'],
												'class' => array(
													'image' => array( 'slider__background' ),
												),
												'attribute' => array(
													'image' => array( 'data-background-for=' . $item['id'] ),
												),
											)
										);
									?>
								<?php endif; ?>
							<?php endforeach; ?>
							<div class="slider__background-overlay overlay overlay_dark"></div>
						</div>
						<!-- - background images -->
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php
	}
}
