<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Portfolio_Fullscreen_Headings_Slider extends Rubenz_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_portfolio_item';

	public function get_name() {
		return 'rubenz-widget-portfolio-fullscreen-headings-slider';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Fullscreen Headings Slider', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'rubenz-dynamic' );
	}

	protected function register_controls() {
		$posts     = $this->get_posts();
		$post_type = self::$_post_type;

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'rubenz' )
					),
					'type'       => Controls_Manager::RAW_HTML,
					'separator'  => 'before',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Enabled', 'rubenz' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'separator'  => 'after',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

		}

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'rubenz' ),
					esc_html__( 'You can edit or re-order your posts', 'rubenz' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'rubenz' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Posts', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'   => esc_html__( 'Number of Posts to Display (0 for all)', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 5,
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'transitions_section',
			array(
				'label' => esc_html__( 'Transitions', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_transition',
			array(
				'label'   => esc_html__( 'Enable AJAX Image Transition', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_section',
			array(
				'label' => esc_html__( 'Slider', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_autoplay',
			array(
				'label'   => esc_html__( 'Autoplay', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'autoplay_delay',
			array(
				'label'     => esc_html__( 'Autoplay Delay (ms)', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'ms' => array(
						'min'  => 1000,
						'max'  => 60000,
						'step' => 100,
					),
				),
				'default'   => array(
					'unit' => 'ms',
					'size' => 6000,
				),
				'condition' => array(
					'enable_autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'speed',
			array(
				'label'   => esc_html__( 'Speed', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'ms' => array(
						'min'  => 100,
						'max'  => 10000,
						'step' => 100,
					),
				),
				'default' => array(
					'unit' => 'ms',
					'size' => 1200,
				),
			)
		);

		$this->add_control(
			'enable_mousewheel_control',
			array(
				'label'   => esc_html__( 'Enable Mousewheel Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'mousewheel_target',
			array(
				'label'     => esc_html__( 'Mousewheel Events Target', 'rubenz' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '.page-wrapper',
				'options'   => array(
					'.page-wrapper' => esc_html__( 'Page Wrapper', 'rubenz' ),
					'container'     => esc_html__( 'Container', 'rubenz' ),
				),
				'condition' => array(
					'enable_mousewheel_control' => 'yes',
				),
			)
		);

		$this->add_control(
			'enable_keyboard_control',
			array(
				'label'   => esc_html__( 'Enable Keyboard Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_touch_control',
			array(
				'label'   => esc_html__( 'Enable Touch Swipes Control', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'heading_controls',
			array(
				'label'     => esc_html__( 'Controls', 'rubenz' ),
				'separator' => 'before',
				'type'      => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'enable_counter',
			array(
				'label'   => esc_html__( 'Enable Counter', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_arrows',
			array(
				'label'   => esc_html__( 'Enable Arrows', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'enable_dots',
			array(
				'label'   => esc_html__( 'Enable Dots', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'slider_overlay_opacity',
			array(
				'label'     => esc_html__( 'Images Overlay Opacity', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'size' => .6,
				),
				'range'     => array(
					'px' => array(
						'max'  => 1,
						'step' => 0.01,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .slider__background.active ~ .slider__background-overlay' => 'opacity: {{SIZE}};',
					'{{WRAPPER}} .slider__background.selected ~ .slider__background-overlay' => 'opacity: {{SIZE}};',
				),
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$posts    = $this->get_posts_to_display();

		$this->add_render_attribute(
			'swiper',
			array(
				'class'      => array( 'swiper', 'swiper-container', 'slider', 'slider-headings', 'js-slider-headings' ),
				'data-speed' => $settings['speed']['size'],
			)
		);

		if ( $settings['enable_autoplay'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-autoplay-enabled' => 'true',
					'data-autoplay-delay'   => $settings['autoplay_delay']['size'],
				)
			);
		}

		if ( $settings['enable_mousewheel_control'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-mousewheel-enabled' => 'true',
					'data-mousewheel-target'  => $settings['mousewheel_target'],
				)
			);
		}

		if ( $settings['enable_keyboard_control'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-keyboard-enabled' => 'true',
				)
			);
		}

		if ( $settings['enable_touch_control'] ) {
			$this->add_render_attribute(
				'swiper',
				array(
					'data-touch-enabled' => 'true',
				)
			);
		}

		?>

		<?php if ( ! empty( $posts ) ) : ?>
			<div class="section section-fullscreen-slider section-headings-slider section-fullheight" data-os-animation="data-os-animation">
				<div class="section-fullheight__inner section-fullscreen-slider__inner">
					<div <?php echo $this->get_render_attribute_string( 'swiper' ); ?>>
						<div class="swiper-wrapper">
							<?php foreach ( $posts as $item ) : ?>
								<?php
								$attrs_link = '';

								if ( ! empty( $item['image_id'] && $settings['enable_transition'] ) ) {
									$attrs_link = 'data-pjax-link=fullscreenSlider';
								}
								?>
								<div class="swiper-slide slider-headings__slide">
									<a class="slider-headings__link" href="<?php echo esc_url( $item['permalink'] ); ?>" <?php echo esc_attr( $attrs_link ); ?> data-slide-id="<?php echo esc_attr( $item['id'] ); ?>">
										<h2 class="split-chars"><?php echo $item['title']; ?></h2>
										<?php if ( $item['description'] ) : ?>
											<p class="split-text"><?php echo $item['description']; ?></p>
										<?php endif; ?>
									</a>
								</div>
							<?php endforeach; ?>
						</div>
						<div class="slider__backgrounds">
							<?php foreach ( $posts as $item ) : ?>
								<?php if ( ! empty( $item['video'] ) ) : ?>
									<video class="slider__background of-cover" src="<?php echo esc_url( $item['video'] ); ?>" poster="<?php echo esc_url( wp_get_attachment_url( $item['image_id'] ) ); ?>" playsinline loop muted autoplay data-background-for="<?php echo esc_attr( $item['id'] ); ?>"></video>
								<?php elseif ( ! empty( $item['image_id'] ) ) : ?>
									<?php
										arts_the_lazy_image(
											array(
												'id'    => $item['image_id'],
												'class' => array(
													'image' => array( 'slider__background' ),
												),
												'attribute' => array(
													'image' => array( 'data-background-for=' . $item['id'] ),
												),
											)
										);
									?>
								<?php endif; ?>
							<?php endforeach; ?>
							<div class="slider__background-overlay overlay overlay_dark"></div>
						</div>
						<!-- - background images -->
						<?php if ( $settings['enable_dots'] ) : ?>
							<div class="slider-headings__footer">
								<div class="slider__dots js-slider-headings__dots">
									<div class="slider__dot slider-headings__dot slider__dot_active"></div>
									<div class="slider__dot slider-headings__dot"></div>
									<div class="slider__dot slider-headings__dot"></div>
									<div class="slider__dot slider-headings__dot"></div>
								</div>
							</div>
							<!-- - dots -->
						<?php endif; ?>
						<?php if ( $settings['enable_counter'] ) : ?>
							<div class="slider__progress slider-headings__progress">
								<div class="swiper swiper-container slider-headings__counter js-slider-headings-counter-current">
									<div class="swiper-wrapper"></div>
								</div>
							</div>
							<!-- - counter -->
						<?php endif; ?>
						<?php if ( $settings['enable_arrows'] ) : ?>
							<div class="slider__arrow slider-headings__arrow slider-headings__arrow_prev js-slider-headings__prev">
								<div class="slider__arrow-inner"><i class="material-icons">keyboard_arrow_left</i></div>
							</div>
							<div class="slider__arrow slider-headings__arrow slider-headings__arrow_next js-slider-headings__next">
								<div class="slider__arrow-inner"><i class="material-icons">keyboard_arrow_right</i></div>
							</div>
							<!-- - nav arrows -->
						<?php endif; ?>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<?php
	}
}
