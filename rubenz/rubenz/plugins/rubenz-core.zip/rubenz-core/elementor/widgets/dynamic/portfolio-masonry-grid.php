<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Portfolio_Masonry_Grid extends Rubenz_Widget_Base {
	protected static $_instance, $_posts, $_post_type = 'arts_portfolio_item';

	public function get_name() {
		return 'rubenz-widget-portfolio-masonry-grid';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Masonry Grid', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-sitemap';
	}

	public function get_categories() {
		return array( 'rubenz-dynamic' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'filter_all_label',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( '"All" filter label', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$posts     = $this->get_posts();
		$post_type = self::$_post_type;

		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		foreach ( $posts as $index => $item ) {

			/**
			 * Heading Toggle
			 */
			$id = 'heading_toggle' . $item['id'];
			$this->add_control(
				$id,
				array(
					'raw'        => sprintf(
						'<h3 class="elementor-control-title"><strong>%1$s</strong>&nbsp;&nbsp;<a href="%2$s" target="_blank"><i class="eicon-edit"></i></a></h3>',
						$item['title'],
						admin_url( 'post.php?post=' . $item['id'] . '&action=edit' ),
						esc_html__( 'Edit', 'rubenz' )
					),
					'type'       => Controls_Manager::RAW_HTML,
					'separator'  => 'before',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

			/**
			 * Toggle
			 */
			$id = 'enabled' . $item['id'];
			$this->add_control(
				$id,
				array(
					'label'      => esc_html__( 'Enabled', 'rubenz' ),
					'type'       => Controls_Manager::SWITCHER,
					'default'    => 'yes',
					'conditions' => array(
						'relation' => 'or',
						'terms'    => array(
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '>',
								'value'    => $index,
							),
							array(
								'name'     => 'posts_amount[size]',
								'operator' => '<=',
								'value'    => '0',
							),
						),
					),
				)
			);

		}

		$this->add_control(
			'dynamic_content_info',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => sprintf(
					'%1$s<br><br>%2$s <a href="%3$s" target="_blank">%4$s</a>',
					esc_html__( 'This widget displays content dynamically from the existing posts. It\'s not editable directly through Elementor Page Builder.', 'rubenz' ),
					esc_html__( 'You can edit or re-order your posts', 'rubenz' ),
					admin_url( 'edit.php?post_type=' . $post_type ),
					esc_html__( 'in WordPress admin panel', 'rubenz' )
				),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Layout
		 */
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			)
		);

		$this->add_control(
			'enable_fancy',
			array(
				'label'     => esc_html__( 'Enable Fancy Grid', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'columns!' => '12',
				),
			)
		);

		/**
		 * Columns
		 */
		$this->add_responsive_control(
			'columns',
			array(
				'label'           => esc_html__( 'Columns', 'rubenz' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => array(
					3  => esc_html__( 'Four Columns', 'rubenz' ),
					4  => esc_html__( 'Three Columns', 'rubenz' ),
					6  => esc_html__( 'Two Columns', 'rubenz' ),
					12 => esc_html__( 'Single Column', 'rubenz' ),
				),
				'render_type'     => 'template',
				'desktop_default' => 4,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			)
		);

		/**
		 * Space Between
		 */
		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => esc_html__( 'Space Between', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 80,
				),
				'tablet_default'  => array(
					'size' => 30,
				),
				'mobile_default'  => array(
					'size' => 15,
				),
				'selectors'       => array(
					'{{WRAPPER}}'                     => 'overflow: hidden;',
					'{{WRAPPER}} .grid'               => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item'         => 'padding: calc({{SIZE}}{{UNIT}} / 2) calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item_caption' => 'padding: calc({{SIZE}}{{UNIT}} / 2 - 1em) calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: {{SIZE}}{{UNIT}};',
					'(tablet){{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: 0;',
					'(mobile){{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: 0;',
				),
				'render_type'     => 'template',
			)
		);

		$this->add_control(
			'enable_counters',
			array(
				'label'   => esc_html__( 'Enable Counters', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Hover
		 */
		$this->start_controls_section(
			'hover_section',
			array(
				'label' => esc_html__( 'Hover', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'zoom_hover_enabled',
			array(
				'label'   => esc_html__( 'Enable Zoom Hover Effect', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => esc_html__( 'Animation', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'image_parallax',
			array(
				'label'   => esc_html__( 'Enable parallax', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'image_parallax_speed',
			array(
				'label'     => esc_html__( 'Parallax Speed', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'factor' => array(
						'min'  => -0.5,
						'max'  => 0.5,
						'step' => 0.01,
					),
				),
				'default'   => array(
					'unit' => 'factor',
					'size' => 0.1,
				),
				'condition' => array(
					'image_parallax' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Posts', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'posts_amount',
			array(
				'label'   => esc_html__( 'Number of Posts to Display (0 for all)', 'rubenz' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'number' => array(
						'min'  => 0,
						'max'  => 16,
						'step' => 1,
					),
				),
				'default' => array(
					'unit' => 'number',
					'size' => 0,
				),
			)
		);

		$this->add_control(
			'enable_filter',
			array(
				'label' => esc_html__( 'Enable Grid Filter', 'rubenz' ),
				'type'  => Controls_Manager::SWITCHER,
			)
		);

		$this->add_control(
			'filter_all_label',
			array(
				'label'     => esc_html__( '"All" label', 'rubenz' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'All', 'rubenz' ),
				'condition' => array(
					'enable_filter' => 'yes',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'transitions_section',
			array(
				'label' => esc_html__( 'Transitions', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		$this->add_control(
			'enable_transition',
			array(
				'label'   => esc_html__( 'Enable AJAX Image Transition', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

	}

	private function _get_taxonomies_to_display( $posts ) {
		$active_taxonomies = array();

		foreach ( $posts as $item ) {
			if ( is_array( $item['categories'] ) ) {
				foreach ( $item['categories'] as $taxonomy ) {

					$arr = array(
						'slug' => $taxonomy->slug,
						'name' => $taxonomy->name,
					);

					// don't add the same item multiple times
					if ( ! in_array( $arr, $active_taxonomies ) ) {
						array_push( $active_taxonomies, $arr );
					}
				}
			}
		}

		return $active_taxonomies;
	}

	protected function render() {
		$settings          = $this->get_settings_for_display();
		$posts             = $this->get_posts_to_display();
		$active_taxonomies = $settings['enable_filter'] ? $this->_get_taxonomies_to_display( $posts ) : array();
		$counter           = 0;

		$col_desktop = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet  = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile  = 'grid__item_mobile-' . $settings['columns_mobile'];

		$this->add_render_attribute(
			'section',
			array(
				'class'                    => array( 'grid', 'js-grid' ),
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			)
		);

		$this->add_render_attribute(
			'sizerAtts',
			array(
				'class' => array( 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		if ( $settings['enable_fancy'] ) {

			$this->add_render_attribute(
				'section',
				array(
					'class' => array( 'grid_fancy', 'js-grid' ),
				)
			);

		}

		?>

		<?php if ( ! empty( $posts ) ) : ?>

			<?php if ( ! empty( $active_taxonomies && $settings['enable_filter'] ) ) : ?>
				<div class="filter js-filter">
					<div class="filter__inner">
						<div class="row">
							<?php if ( ! empty( $settings['filter_all_label'] ) ) : ?>
								<div class="col-xl-auto col-12 filter__item filter__item_active js-filter__item" data-filter="*">
									<div><?php echo esc_attr( $settings['filter_all_label'] ); ?></div>
								</div>
							<?php endif; ?>
							<?php foreach ( $active_taxonomies as $item ) : ?>
								<div class="col-xl-auto col-12 filter__item js-filter__item" data-filter=".category-<?php echo $item['slug']; ?>">
									<div><?php echo $item['name']; ?></div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>

			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
					<?php foreach ( $posts as $index => $item ) : ?>
						<?php

						$index++;
						$counter++;
						if ( $counter < 10 ) {
							$counter_string = '00' . $counter;
						} else {
							$counter_string = '0' . $counter;
						}

						$this->add_render_attribute(
							'itemAtts' . $index,
							array(
								'class' => array( 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile ),
							)
						);

						$this->add_render_attribute(
							'linkAtts',
							array(
								'class'          => array( 'hover-zoom', 'figure-portfolio' ),
								'href'           => $item['permalink'],
								'data-post-id'   => $item['id'],
								'data-pjax-link' => ! $settings['enable_transition'] || empty( $item['image_id'] ) ? '' : 'masonryGrid',
							),
							true,
							true
						);

						if ( $settings['zoom_hover_enabled'] ) {
							$this->add_render_attribute( 'linkAtts', 'class', 'hover-zoom' );
						}

						// categories
						if ( array_key_exists( 'categories', $item ) && is_array( $item['categories'] ) ) {

							$categories = array();

							foreach ( $item['categories'] as $taxonomy ) {

								$this->add_render_attribute(
									'itemAtts' . $index,
									array(
										'class' => 'category-' . esc_attr( $taxonomy->slug ),
									)
								);
								$categories[] .= $taxonomy->name;

							}
						}

						?>
						<div <?php echo $this->get_render_attribute_string( 'itemAtts' . $index ); ?>>
							<a <?php echo $this->get_render_attribute_string( 'linkAtts' ); ?>>
								<?php if ( $settings['enable_counters'] ) : ?>
									<div class="figure-portfolio__counter"><?php echo $counter_string; ?></div>
								<?php endif; ?>
								<div class="figure-portfolio__content">
									<div class="figure-portfolio__wrapper-img">
									<?php if ( $settings['zoom_hover_enabled'] ) : ?>
										<div class="hover-zoom__inner">
											<div class="hover-zoom__zoom">
									<?php endif; ?>
											<?php
												arts_the_lazy_image(
													array(
														'id'   => $item['image_id'],
														'type' => 'image',
														'parallax' => array(
															'enabled' => $settings['image_parallax'],
															'factor' => is_array( $settings['image_parallax_speed'] ) ? $settings['image_parallax_speed']['size'] : 0,
														),
													)
												);
											?>
									<?php if ( $settings['zoom_hover_enabled'] ) : ?>
											</div>
										</div>
									<?php endif; ?>
									</div>
									<?php if ( ! empty( $item['title'] ) ) : ?>
										<h3><?php echo $item['title']; ?></h3>
									<?php endif; ?>
								</div>
							</a>
						</div>
					<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php
	}
}
