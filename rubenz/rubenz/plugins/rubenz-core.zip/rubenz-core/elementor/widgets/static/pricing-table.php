<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Pricing_Table extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-pricing-table';
	}

	public function get_title() {
		return esc_html__( 'Pricing Table', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_value',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Amount', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_symbol_before',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Symbol Before', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'amount_symbol_after',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Symbol After', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
			'integration-class' => 'WPML_Rubenz_Elementor_Pricing_Table',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'pricing_heading',
			array(
				'label'       => esc_html__( 'Heading', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Edit heading...', 'rubenz' ),
			)
		);

		$this->add_control(
			'amount_heading',
			array(
				'label'     => esc_html__( 'Amount', 'rubenz' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'amount_value',
			array(
				'label'       => esc_html__( 'Value', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => '100',
			)
		);

		$this->add_control(
			'amount_symbol_before',
			array(
				'label'   => esc_html__( 'Symbol Before', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '$',
			)
		);

		$this->add_control(
			'amount_symbol_after',
			array(
				'label'   => esc_html__( 'Symbol After', 'rubenz' ),
				'type'    => Controls_Manager::TEXT,
				'default' => null,
			)
		);

		$this->add_control(
			'features_heading',
			array(
				'label'     => esc_html__( 'Features', 'rubenz' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'feature',
			array(
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
			)
		);

		$this->add_control(
			'features',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ feature }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Button
		 */
		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Button', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Button Title
		 */
		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Title', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Select Plan', 'rubenz' ),
			)
		);

		/**
		 * Button URL
		 */
		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Link', 'rubenz' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => 'https://...',
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		/**
		 * Button Style
		 */
		$this->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'rubenz' ),
					'button_solid'    => esc_html__( 'Solid', 'rubenz' ),
				),
				'default'     => 'button_solid',
			)
		);

		/**
		 * Button Color
		 */
		$this->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_dark'  => esc_html__( 'Dark', 'rubenz' ),
					'button_light' => esc_html__( 'Light', 'rubenz' ),
					'button_black' => esc_html__( 'Black', 'rubenz' ),
					'button_white' => esc_html__( 'White', 'rubenz' ),
				),
				'default'     => 'button_dark',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Style
		 */
		$this->start_controls_section(
			'style_section',
			array(
				'label' => esc_html__( 'Style', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Featured Highlight
		 */
		$this->add_control(
			'is_pricing_featured',
			array(
				'label'        => esc_html__( 'Enable Featured Highlight', 'rubenz' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => null,
				'return_value' => 'figure-pricing_featured',
			)
		);

		/**
		 * Equal Height Pricing Tables
		 */
		$this->add_control(
			'is_height_equal',
			array(
				'label'       => esc_html__( 'Set height to the tallest pricing table.', 'rubenz' ),
				'description' => esc_html__( 'Useful if you have the pricing tables of different heights. Applicable for the current row in layout.', 'rubenz' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'selectors'   => array(
					'{{WRAPPER}}' => 'height: 100%;',
					'{{WRAPPER}} .elementor-widget-container' => 'height: 100%;',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'pricing_heading' );
		$this->add_inline_editing_attributes( 'amount_value' );
		$this->add_inline_editing_attributes( 'amount_symbol_before' );
		$this->add_inline_editing_attributes( 'amount_symbol_after' );
		$this->add_inline_editing_attributes( 'button_title' );
		?>
		<div class="figure-pricing <?php echo $settings['is_pricing_featured']; ?>">
			<?php if ( ! empty( $settings['pricing_heading'] ) ) : ?>
				<div class="figure-pricing__header">
					<h4 <?php echo $this->get_render_attribute_string( 'pricing_heading' ); ?>><?php echo $settings['pricing_heading']; ?></h4>
					<?php if ( ! empty( $settings['amount_value'] ) ) : ?>
						<div class="figure-pricing__cost">
							<?php if ( ! empty( $settings['amount_symbol_before'] ) ) : ?>
								<div class="figure-pricing__cost-sign figure-pricing__cost-sign_before">
									<span <?php echo $this->get_render_attribute_string( 'amount_symbol_before' ); ?>><?php echo $settings['amount_symbol_before']; ?></span>
								</div>
							<?php endif; ?>
							<div class="figure-pricing__amount">
								<span <?php echo $this->get_render_attribute_string( 'amount_value' ); ?>><?php echo $settings['amount_value']; ?></span>
							</div>
							<?php if ( ! empty( $settings['amount_symbol_after'] ) ) : ?>
								<div class="figure-pricing__cost-sign figure-pricing__cost-sign_after">
									<span <?php echo $this->get_render_attribute_string( 'amount_symbol_after' ); ?>><?php echo $settings['amount_symbol_after']; ?></span>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['features'] ) ) : ?>
				<ul class="figure-pricing__features">
					<?php foreach ( $settings['features'] as $index => $item ) : ?>
						<?php
							$rowKey = $this->get_repeater_setting_key( 'feature', 'features', $index );
							$this->add_inline_editing_attributes( $rowKey );
						?>
						<li class="figure-pricing__feature">
							<span <?php echo $this->get_render_attribute_string( $rowKey ); ?>><?php echo $item['feature']; ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php if ( ! empty( $settings['button_title'] ) ) : ?>
				<div class="figure-pricing__wrapper-button">
					<?php
						$this->add_render_attribute(
							'button',
							array(
								'class' => array( 'button', 'button_fullwidth', $settings['button_style'], $settings['button_color'] ),
								'href'  => $settings['button_link']['url'],
							)
						);

					if ( $settings['button_link']['is_external'] ) {
						$this->add_render_attribute( 'button', 'target', '_blank' );
					}

					if ( $settings['button_link']['nofollow'] ) {
						$this->add_render_attribute( 'button', 'rel', 'nofollow' );
					}
					?>
					<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><span <?php echo $this->get_render_attribute_string( 'button_title' ); ?>><?php echo $settings['button_title']; ?></span></a>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'pricing_heading' );
			view.addInlineEditingAttributes( 'amount_value' );
			view.addInlineEditingAttributes( 'amount_symbol_before' );
			view.addInlineEditingAttributes( 'amount_symbol_after' );
			view.addInlineEditingAttributes( 'button_title' );
		#>
		<div class="figure-pricing {{{ settings.is_pricing_featured }}}">
			<# if (settings.pricing_heading) { #>
				<div class="figure-pricing__header">
					<h4 {{{ view.getRenderAttributeString( 'pricing_heading' ) }}}>{{{ settings.pricing_heading }}}</h4>
					<# if (settings.amount_value) { #>
						<div class="figure-pricing__cost">
							<# if (settings.amount_symbol_before) { #>
								<div class="figure-pricing__cost-sign figure-pricing__cost-sign_before">
									<span {{{ view.getRenderAttributeString( 'amount_symbol_before' ) }}}>{{{ settings.amount_symbol_before }}}</span>
								</div>
							<# } #>
							<div class="figure-pricing__amount">
								<span {{{ view.getRenderAttributeString( 'amount_value' ) }}}>{{{ settings.amount_value }}}</span>
							</div>
							<# if (settings.amount_symbol_after) { #>
								<div class="figure-pricing__cost-sign figure-pricing__cost-sign_after">
									<span {{{ view.getRenderAttributeString( 'amount_symbol_after' ) }}}>{{{ settings.amount_symbol_after }}}</span>
								</div>
							<# } #>
						</div>
					<# } #>
				</div>
			<# } #>
			<# if (settings.features.length ) { #>
				<ul class="figure-pricing__features">
					<# _.each( settings.features, function(item, index) { #>
						<#
							var rowKey = view.getRepeaterSettingKey( 'feature', 'features', index );
							view.addInlineEditingAttributes( rowKey );
						#>
						<li class="figure-pricing__feature">
							<span {{{ view.getRenderAttributeString( rowKey ) }}}>{{{ item.feature }}}</span>
						</li>
					<# }); #>
				</ul>
			<# } #>
			<# if (settings.button_title) { #>
				<#
					view.addRenderAttribute(
						'button', {
							'class': [ 'button', 'button_fullwidth', settings.button_style, settings.button_color ],
							'href': settings.button_link.url,
						}
					);

					if ( settings.button_link.is_external ) {
						view.addRenderAttribute( 'button', 'target', '_blank' );
					}

					if ( settings.button_link.nofollow ) {
						view.addRenderAttribute( 'button', 'rel', 'nofollow' );
					}
				#>
				<div class="figure-pricing__wrapper-button">
					<a {{{ view.getRenderAttributeString( 'button' ) }}}><span {{{ view.getRenderAttributeString( 'button_title' ) }}}>{{{ settings.button_title }}}</span></a>
				</div>
			<# } #>
		</div>
		<?php
	}

}
