<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Logo_Description extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-logo-description';
	}

	public function get_title() {
		return esc_html__( 'Logo with Description', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'description',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Short Description', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Choose Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'description',
			array(
				'label'   => esc_html__( 'Short Description', 'rubenz' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Company...', 'rubenz' ),
			)
		);

		$this->add_control(
			'enable_grayscale',
			array(
				'label'        => esc_html__( 'Enable Grayscale Filter', 'rubenz' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'grayscale',
				'default'      => 'grayscale',
			)
		);

		$this->add_control(
			'background_theme',
			array(
				'label'   => esc_html__( 'Background Color Theme', 'rubenz' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					''                      => esc_html__( 'None', 'rubenz' ),
					'bg-white'              => esc_html__( 'Pure White', 'rubenz' ),
					'bg-light-grey'         => esc_html__( 'Light 1', 'rubenz' ),
					'bg-light'              => esc_html__( 'Light 2', 'rubenz' ),
					'bg-blue-grey'          => esc_html__( 'Blue Grey 1', 'rubenz' ),
					'bg-blue-grey-dark'     => esc_html__( 'Blue Grey 2', 'rubenz' ),
					'bg-dark color-white'   => esc_html__( 'Dark 1', 'rubenz' ),
					'bg-dark-2 color-white' => esc_html__( 'Dark 2', 'rubenz' ),
					'bg-black color-white'  => esc_html__( 'Dark 3', 'rubenz' ),
				),
				'default' => 'bg-light-grey',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'description' );

		$this->add_render_attribute( 'section', 'class', array( 'text-center', 'figure-logo', $settings['enable_grayscale'], $settings['background_theme'] ) );
		?>
		<?php if ( ! empty( $settings['image']['url'] ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<?php
					arts_the_lazy_image(
						array(
							'id'   => $settings['image']['id'],
							'type' => 'image',
						)
					);
				?>
				<?php if ( ! empty( $settings['description'] ) ) : ?>
					<div class="figure-logo__description">
						<p <?php echo $this->get_render_attribute_string( 'description' ); ?>><?php echo $settings['description']; ?></p>
						<div class="figure-logo__line"></div>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php
	}
}
