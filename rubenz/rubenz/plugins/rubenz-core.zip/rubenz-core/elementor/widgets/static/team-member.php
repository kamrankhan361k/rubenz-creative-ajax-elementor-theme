<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Team_Member extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-team-member';
	}

	public function get_title() {
		return esc_html__( 'Team Member', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'name',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Name', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'position',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Position', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'name',
			array(
				'label'       => esc_html__( 'Name', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Edit name...', 'rubenz' ),
			)
		);

		$this->add_control(
			'position',
			array(
				'label'       => esc_html__( 'Position', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Edit position...', 'rubenz' ),
			)
		);

		$this->add_control(
			'social_heading',
			array(
				'label'     => esc_html__( 'Social Media', 'rubenz' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'social_link',
			array(
				'label'         => esc_html__( 'Link', 'rubenz' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://...', 'rubenz' ),
				'show_external' => true,
				'default'       => array(
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$repeater->add_control(
			'social_icon',
			array(
				'label' => esc_html__( 'Icon', 'rubenz' ),
				'type'  => Controls_Manager::ICON,
			)
		);

		$this->add_control(
			'social',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ social_icon.replace("fa fa-", "") }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

		/**
		 * Section Avatar
		 */
		$this->start_controls_section(
			'avatar_section',
			array(
				'label' => esc_html__( 'Avatar', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'avatar',
			array(
				'label'   => esc_html__( 'Choose Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'enable_grayscale',
			array(
				'label'        => esc_html__( 'Enable Grayscale Filter', 'rubenz' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'grayscale',
				'default'      => 'grayscale',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'name' );
		$this->add_inline_editing_attributes( 'position' );

		$this->add_render_attribute( 'item', 'class', 'figure-member' );

		if ( $settings['social'] ) {
			$this->add_render_attribute( 'item', 'class', 'figure-member_has-social' );
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'item' ); ?>>
			<?php if ( ! empty( $settings['avatar']['url'] ) ) : ?>
				<div class="figure-member__wrapper-img">
					<?php
						arts_the_lazy_image(
							array(
								'id'    => $settings['avatar']['id'],
								'type'  => 'image',
								'class' => array(
									'wrapper' => array( $settings['enable_grayscale'] ),
								),
							)
						);
					?>
					<?php if ( $settings['social'] ) : ?>
						<div class="figure-member__social">
							<ul class="social">
								<?php foreach ( $settings['social'] as $item ) : ?>
									<li class="social__item">
										<?php
											$target   = $item['social_link']['is_external'] ? ' target="_blank"' : '';
											$nofollow = $item['social_link']['nofollow'] ? ' rel="nofollow"' : '';
										?>
										<a class="<?php echo $item['social_icon']; ?>" href="<?php echo $item['social_link']['url']; ?>" <?php echo $target . ' ' . $nofollow; ?>>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
					<div class="figure-member__overlay"></div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $settings['name'] || ! empty( $settings['position'] ) ) ) : ?>
				<div class="figure-member__content">
					<?php if ( ! empty( $settings['position'] ) ) : ?>
						<div class="figure-member__position">
							<span <?php echo $this->get_render_attribute_string( 'position' ); ?>><?php echo $settings['position']; ?></span>
						</div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['name'] ) ) : ?>
						<h4 <?php echo $this->get_render_attribute_string( 'name' ); ?>><?php echo $settings['name']; ?></h4>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'name' );
			view.addInlineEditingAttributes( 'position' );

			view.addRenderAttribute( 'item', 'class', 'figure-member' );

			if ( settings.social.length ) {
				view.addRenderAttribute( 'item', 'class', 'figure-member_has-social' );
			}
		#>

		<div {{{ view.getRenderAttributeString( 'item' ) }}}>
			<# if (settings.avatar) { #>
				<#

					view.addRenderAttribute(
						'wrapper', {
							'class': [ settings.enable_grayscale ]
						}
					);

					view.addRenderAttribute(
						'img', {
							'src': settings.avatar.url,
							'alt': '',
						}
					);

				#>
				<div class="figure-member__wrapper-img">
					<div {{{ view.getRenderAttributeString( 'wrapper' ) }}}>
						<img {{{ view.getRenderAttributeString( 'img' ) }}}>
					</div>
					<# if (settings.social.length) { #>
						<div class="figure-member__social">
							<ul class="social">
								<# _.each( settings.social, function(item) { #>
									<li class="social__item">
										<#
											var target = item.social_link.is_external ? ' target="_blank"' : '';
											var nofollow = item.social_link.nofollow ? ' rel="nofollow"' : '';
										#>
										<a class="{{{ item.social_icon }}}" href="{{{ item.social_link.url }}}" {{{ target }}} {{{ nofollow }}}>
										</a>
									</li>
								<# }); #>
							</ul>
						</div>
						<div class="figure-member__overlay"></div>
					<# } #>
				</div>
			<# } #>
			<# if ( settings.name || settings.position ) { #>
				<div class="figure-member__content">
					<# if ( settings.position ) { #>
						<div class="figure-member__position">
							<span {{{ view.getRenderAttributeString( 'position' ) }}}>{{{ settings.position }}}</span>
						</div>
					<# } #>
					<# if (settings.name) { #>
						<h4 {{{ view.getRenderAttributeString( 'name' ) }}}>{{{ settings.name }}}</h4>
					<# } #>
				</div>
			<# } #>
		</div>
		<?php
	}
}
