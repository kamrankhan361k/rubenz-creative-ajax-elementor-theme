<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Counters extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-counters';
	}

	public function get_title() {
		return esc_html__( 'Counters', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(),
			'integration-class' => 'WPML_Rubenz_Elementor_Counters',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'label',
			array(
				'label'       => esc_html__( 'Label', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Label...', 'rubenz' ),
			)
		);

		$repeater->add_control(
			'counter_start',
			array(
				'label'   => esc_html__( 'Start Number', 'rubenz' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10000,
				'step'    => 1,
				'default' => 0,
			)
		);

		$repeater->add_control(
			'counter_target',
			array(
				'label'   => esc_html__( 'Target Number', 'rubenz' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10000,
				'step'    => 1,
				'default' => 10,
			)
		);

		$this->add_control(
			'counters',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ label }}}',
				'prevent_empty' => false,
			)
		);

		$this->add_control(
			'counters_duration',
			array(
				'label'   => esc_html__( 'Animation Duration (seconds)', 'rubenz' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10,
				'step'    => 1,
				'default' => 4,
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if ( ! empty( $settings['counters'] ) ) : ?>
			<div class="aside-counters">
				<div class="container">
					<div class="row justify-content-center">
						<?php foreach ( $settings['counters'] as $index => $item ) : ?>
							<?php
								$labelKey = $this->get_repeater_setting_key( 'label', 'counters', $index );
								$this->add_inline_editing_attributes( $labelKey );

								$this->add_render_attribute(
									'counter',
									array(
										'class' => array( 'counter', 'js-counter' ),
										'data-counter-start' => $item['counter_start'],
										'data-counter-target' => $item['counter_target'],
										'data-counter-duration' => $settings['counters_duration'],
									),
									true,
									true
								);
							?>
							<div class="col-sm-4 aside-counters__wrapper-item">
								<div <?php echo $this->get_render_attribute_string( 'counter' ); ?>>
									<div class="counter__number js-counter__number"><?php echo $item['counter_target']; ?></div>
									<div class="counter__label">
										<span <?php echo $this->get_render_attribute_string( $labelKey ); ?>><?php echo $item['label']; ?></span>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		<?php endif; ?>
		<?php
	}

	protected function content_template() {
		?>
		<# if ( settings.counters.length ) { #>
			<div class="aside-counters">
				<div class="container">
					<div class="row justify-content-center">
						<# _.each( settings.counters, function(item, index) { #>
							<#
								var labelKey = view.getRepeaterSettingKey( 'label', 'counters', index );
								view.addInlineEditingAttributes( labelKey );

								view.addRenderAttribute(
									'counter', {
										'class': [ 'counter', 'js-counter' ],
										'data-counter-start': item.counter_start,
										'data-counter-target': item.counter_target,
										'data-counter-duration': settings.counters_duration,
									}, true, true
								);
							#>
							<div class="col-sm-4 aside-counters__wrapper-item">
								<div {{{ view.getRenderAttributeString( 'counter' ) }}}>
									<div class="counter__number js-counter__number">{{{ item.counter_target }}}</div>
									<div class="counter__label">
										<span {{{ view.getRenderAttributeString( labelKey ) }}}>{{{ item.label }}}</span>
									</div>
								</div>
							</div>
						<# }); #>
					</div>
				</div>
			</div>
		<# } #>
		<?php
	}
}
