<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Header_Section extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-header-section';
	}

	public function get_title() {
		return esc_html__( 'Header Section', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'subheading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Subheading', 'rubenz' ) ),
					'editor_type' => 'AREA',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'rubenz' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Heading...', 'rubenz' ),
			)
		);

		$this->add_control(
			'subheading',
			array(
				'label'   => esc_html__( 'Subheading', 'rubenz' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 10,
				'default' => esc_html__( 'Subheading...', 'rubenz' ),
			)
		);

		$this->add_control(
			'show_decoration_line',
			array(
				'label'   => esc_html__( 'Show Line Decoration', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			)
		);

		$this->add_control(
			'header_layout',
			array(
				'label'   => esc_html__( 'Header Layout', 'rubenz' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => array(
					'justify-content-between' => esc_html__( 'Left + Right', 'rubenz' ),
					'justify-content-center'  => esc_html__( 'Centered', 'rubenz' ),
				),
				'default' => 'justify-content-between',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Animation
		 */
		$this->start_controls_section(
			'animation_section',
			array(
				'label' => esc_html__( 'Animation', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * OS Animation
		 */
		$this->add_control(
			'enable_animation',
			array(
				'label'   => esc_html__( 'Enable on-scroll animation', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'subheading' );

		$this->add_render_attribute( 'section', 'class', array( 'section-content', 'container', 'section-content__container' ) );
		$this->add_render_attribute( 'row', 'class', array( 'row', 'section-content__row', $settings['header_layout'] ) );
		$this->add_render_attribute( 'colLeft', 'class', array( 'section__header', 'section-content__inner_header' ) );
		$this->add_render_attribute( 'colRight', 'class', array( 'section-content__inner', 'section-content__inner_text' ) );
		$this->add_render_attribute( 'heading', 'class', 'split-chars' );
		$this->add_render_attribute( 'subheading', 'class', 'split-text' );

		if ( $settings['enable_animation'] ) {
			$this->add_render_attribute( 'section', 'data-os-animation' );
		}

		if ( $settings['header_layout'] == 'justify-content-between' ) {
			$this->add_render_attribute( 'colLeft', 'class', array( 'col-lg-5' ) );
			$this->add_render_attribute( 'colRight', 'class', array( 'col-lg-6' ) );
		} else {
			$this->add_render_attribute( 'row', 'class', array( 'text-center' ) );
			$this->add_render_attribute( 'colLeft', 'class', array( 'col-lg-10' ) );
			$this->add_render_attribute( 'colRight', 'class', array( 'col-lg-10' ) );
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<div <?php echo $this->get_render_attribute_string( 'row' ); ?>>
				<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'colLeft' ); ?>>
						<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
						<?php if ( $settings['show_decoration_line'] ) : ?>
							<div class="section__headline"></div>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $settings['subheading'] ) ) : ?>
					<div <?php echo $this->get_render_attribute_string( 'colRight' ); ?>>
						<h3 <?php echo $this->get_render_attribute_string( 'subheading' ); ?>><?php echo $settings['subheading']; ?></h3>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'heading' );
			view.addInlineEditingAttributes( 'subheading' );

			view.addRenderAttribute( 'section', 'class', [ 'section-content', 'container', 'section-content__container' ] );
			view.addRenderAttribute( 'row', 'class', [ 'row', 'section-content__row', settings.header_layout ] );
			view.addRenderAttribute( 'colLeft', 'class', [ 'section__header', 'section-content__inner_header' ] );
			view.addRenderAttribute( 'colRight', 'class', [ 'section-content__inner', 'section-content__inner_text' ] );
			view.addRenderAttribute( 'heading', 'class', ['split-chars'] );
			view.addRenderAttribute( 'subheading', 'class', ['split-text'] );

			if ( settings.header_layout == 'justify-content-between' ) {
				view.addRenderAttribute( 'colLeft', 'class', [ 'col-lg-5' ] );
				view.addRenderAttribute( 'colRight', 'class', [ 'col-lg-6' ] );
			} else {
				view.addRenderAttribute( 'row', 'class', [ 'text-center' ] );
				view.addRenderAttribute( 'colLeft', 'class', [ 'col-lg-10' ] );
				view.addRenderAttribute( 'colRight', 'class', [ 'col-lg-10' ] );
			}
		#>

		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<div {{{ view.getRenderAttributeString( 'row' ) }}}>
				<# if ( settings.heading ) { #>
					<div {{{ view.getRenderAttributeString( 'colLeft' ) }}}>
						<h2 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h2>
						<# if ( settings.show_decoration_line ) { #>
							<div class="section__headline"></div>
						<# } #>
					</div>
				<# } #>
				<# if ( settings.subheading ) { #>
					<div {{{ view.getRenderAttributeString( 'colRight' ) }}}>
						<h3 {{{ view.getRenderAttributeString( 'subheading' ) }}}>{{{ settings.subheading }}}</h3>
					</div>
				<# } #>
			</div>
		</div>

		<?php
	}
}
