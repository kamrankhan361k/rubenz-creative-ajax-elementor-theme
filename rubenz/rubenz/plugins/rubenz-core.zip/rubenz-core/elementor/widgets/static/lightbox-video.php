<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Lightbox_Video extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-lightbox-video';
	}

	public function get_title() {
		return esc_html__( 'Lightbox Video', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Video URL', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'image_section',
			array(
				'label' => esc_html__( 'Background', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Background Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'image_parallax',
			array(
				'label'     => esc_html__( 'Enable parallax', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_control(
			'image_parallax_speed',
			array(
				'label'     => esc_html__( 'Parallax Speed', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'factor' => array(
						'min'  => -0.5,
						'max'  => 0.5,
						'step' => 0.01,
					),
				),
				'default'   => array(
					'unit' => 'factor',
					'size' => 0.1,
				),
				'condition' => array(
					'image_parallax' => 'yes',
					'image!'         => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_control(
			'image_overlay_opacity',
			array(
				'label'     => esc_html__( 'Image Overlay Opacity', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => array(
					'size' => .6,
				),
				'range'     => array(
					'px' => array(
						'max'  => 1,
						'step' => 0.01,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .section-video__overlay' => 'opacity: {{SIZE}};',
				),
				'condition' => array(
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'video_section',
			array(
				'label' => esc_html__( 'Video', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'link',
			array(
				'label'         => esc_html__( 'Video URL', 'rubenz' ),
				'type'          => Controls_Manager::URL,
				'show_external' => false,
				'placeholder'   => sprintf( '%1s: %2s', esc_html__( 'Example', 'rubenz' ), 'https://youtu.be/watch?v=BsekcY04xvQ' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Video...', 'rubenz' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'section', 'class', array( 'section-video', 'section_pt', 'section_pb', 'bg-black-0', 'color-white' ) );

		if ( $settings['image_parallax'] ) {
			$this->add_render_attribute(
				'section',
				array(
					'data-art-parallax'        => 'true',
					'data-art-parallax-factor' => $settings['image_parallax_speed']['size'],
				)
			);
		}

		$this->add_inline_editing_attributes( 'heading' );
		?>
		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<a class="container section-video__link mfp-iframe js-video" href="<?php echo $settings['link']['url']; ?>">
				<?php if ( ! empty( $settings['heading'] ) ) : ?>
					<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
				<?php endif; ?>
				<div class="section-video__icon material-icons">play_arrow</div>
			</a>
			<?php if ( ! empty( $settings['image']['url'] ) ) : ?>
				<?php
					arts_the_lazy_image(
						array(
							'id'    => $settings['image']['id'],
							'type'  => 'background',
							'class' => array(
								'wrapper' => array(),
								'image'   => array( 'art-parallax__bg' ),
							),
						)
					);
				?>
				<div class="overlay overlay_dark section-video__overlay"></div>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addRenderAttribute( 'section', 'class', [ 'section-video', 'section_pt', 'section_pb', 'bg-black-0', 'color-white' ] );

			view.addRenderAttribute(
				'img', {
					'class': [ 'lazy-bg', 'art-parallax__bg' ],
					'data-src': settings.image.url,
				}
			);

			if ( settings.image_parallax ) {
				view.addRenderAttribute(
					'section', {
						'data-art-parallax': 'true',
						'data-art-parallax-factor': settings.image_parallax_speed.size,
					}
				);
			}

			view.addInlineEditingAttributes( 'heading' );
		#>
		<div {{{ view.getRenderAttributeString( 'section' ) }}}>
			<a class="container section-video__link mfp-iframe js-video" href="{{{ settings.link.url }}}">
				<# if ( settings.heading ) { #>
					<h2 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h2>
				<# } #>
				<div class="section-video__icon material-icons">play_arrow</div>
			</a>
			<# if ( settings.image.url ) { #>
				<div {{{ view.getRenderAttributeString( 'img' ) }}}>
					<div class="overlay overlay_dark section-video__overlay"></div>
				</div>
			<# } #>
		</div>
		<?php
	}

}
