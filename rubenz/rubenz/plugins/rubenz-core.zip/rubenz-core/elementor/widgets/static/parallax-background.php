<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Parallax_Background extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-parallax-background';
	}

	public function get_title() {
		return esc_html__( 'Parallax Background', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'caption',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Caption', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Choose Image', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$this->add_control(
			'image_placement',
			array(
				'label'     => esc_html__( 'Image Placement', 'rubenz' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => array(
					'image'      => array(
						'title' => esc_html__( 'Normal Image', 'rubenz' ),
						'icon'  => 'eicon-image-bold',
					),
					'background' => array(
						'title' => esc_html__( 'Background', 'rubenz' ),
						'icon'  => 'eicon-image',
					),
				),
				'default'   => 'image',
				'toggle'    => false,
				'condition' => array(
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_responsive_control(
			'min_height',
			array(
				'label'           => esc_html__( 'Background Height', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'desktop_default' => array(
					'size' => 800,
					'unit' => 'px',
				),
				'tablet_default'  => array(
					'size' => 70,
					'unit' => 'vh',
				),
				'mobile_default'  => array(
					'size' => 50,
					'unit' => 'vh',
				),
				'range'           => array(
					'px' => array(
						'min' => 0,
						'max' => 1440,
					),
					'vh' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'size_units'      => array( 'px', 'vh' ),
				'selectors'       => array(
					'{{WRAPPER}} .section-image__wrapper' => 'height: 1px; min-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .section-image__wrapper:after' => 'content: ""; min-height: inherit;', // Hack for IE11
				),
				'condition'       => array(
					'image_placement' => 'background',
					'image!'          => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_control(
			'image_parallax',
			array(
				'label'     => esc_html__( 'Enable parallax', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_control(
			'image_parallax_speed',
			array(
				'label'     => esc_html__( 'Parallax Speed', 'rubenz' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'factor' => array(
						'min'  => -0.5,
						'max'  => 0.5,
						'step' => 0.01,
					),
				),
				'default'   => array(
					'unit' => 'factor',
					'size' => 0.1,
				),
				'condition' => array(
					'image_parallax' => 'yes',
					'image!'         => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->add_control(
			'caption',
			array(
				'label'       => esc_html__( 'Caption', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Caption...', 'rubenz' ),
				'condition'   => array(
					'image!' => array(
						'id'  => '',
						'url' => '',
					),
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => esc_html__( 'Image Alignment', 'rubenz' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'section text-center'       => array(
						'title' => esc_html__( 'Fullwidth', 'rubenz' ),
						'icon'  => 'eicon-h-align-stretch',
					),
					'section_w-container-left'  => array(
						'title' => esc_html__( 'Left', 'rubenz' ),
						'icon'  => 'eicon-h-align-left',
					),
					'container text-center'     => array(
						'title' => esc_html__( 'Center', 'rubenz' ),
						'icon'  => 'eicon-h-align-center',
					),
					'section_w-container-right' => array(
						'title' => esc_html__( 'Right', 'rubenz' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default' => 'section text-center',
				'toggle'  => false,
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'caption' );
		$this->add_render_attribute( 'section', 'class', array( 'section-image', $settings['layout'] ) );
		?>
		<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
			<?php if ( $settings['image_placement'] == 'background' ) : ?>
				<?php
					arts_the_lazy_image(
						array(
							'id'       => $settings['image']['id'],
							'type'     => 'background',
							'class'    => array(
								'wrapper' => array( 'section-image__wrapper' ),
								'image'   => array( 'art-parallax__bg' ),
							),
							'parallax' => array(
								'enabled' => $settings['image_parallax'],
								'factor'  => is_array( $settings['image_parallax_speed'] ) ? $settings['image_parallax_speed']['size'] : 0,
							),
						)
					);
				?>
			<?php elseif ( $settings['image_placement'] == 'image' ) : ?>
				<?php
					arts_the_lazy_image(
						array(
							'id'       => $settings['image']['id'],
							'type'     => 'image',
							'parallax' => array(
								'enabled' => $settings['image_parallax'],
								'factor'  => is_array( $settings['image_parallax_speed'] ) ? $settings['image_parallax_speed']['size'] : 0,
							),
						)
					);
				?>
			<?php endif; ?>
			<?php if ( ! empty( $settings['caption'] ) ) : ?>
				<h5 <?php echo $this->get_render_attribute_string( 'caption' ); ?>><?php echo $settings['caption']; ?></h5>
			<?php endif; ?>
		</div>
		<?php
	}
}
