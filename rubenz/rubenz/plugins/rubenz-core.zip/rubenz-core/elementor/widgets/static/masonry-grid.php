<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Masonry_Grid extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-masonry-grid';
	}

	public function get_title() {
		return esc_html__( 'Masonry Grid & Gallery', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	private $breakpoint_lg;

	protected function register_controls() {
		$this->breakpoint_lg = get_option( 'elementor_viewport_lg', 992 );

		/**
		 * Section Content
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Images', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Gallery Lightbox
		 */
		$this->add_control(
			'gallery',
			array(
				'type'    => Controls_Manager::GALLERY,
				'default' => array(),
			)
		);

		$this->end_controls_section();

		/**
		 * Section Settings
		 */
		$this->start_controls_section(
			'settings_section',
			array(
				'label' => esc_html__( 'Settings', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			)
		);

		/**
		 * Enable Lightbox
		 */
		$this->add_control(
			'lightbox',
			array(
				'label'   => esc_html__( 'Enable Lightbox', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		/**
		 * Enable Captions
		 */
		$this->add_control(
			'enable_captions',
			array(
				'label'   => esc_html__( 'Enable Image Captions', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Section Layout
		 */
		$this->start_controls_section(
			'layout_section',
			array(
				'label' => esc_html__( 'Layout', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			)
		);

		$this->add_control(
			'enable_fancy',
			array(
				'label'     => esc_html__( 'Enable Fancy Grid', 'rubenz' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => 'yes',
				'condition' => array(
					'columns!' => '12',
				),
			)
		);

		/**
		 * Columns
		 */
		$this->add_responsive_control(
			'columns',
			array(
				'label'           => esc_html__( 'Columns', 'rubenz' ),
				'type'            => Controls_Manager::SELECT,
				'options'         => array(
					3  => esc_html__( 'Four Columns', 'rubenz' ),
					4  => esc_html__( 'Three Columns', 'rubenz' ),
					6  => esc_html__( 'Two Columns', 'rubenz' ),
					12 => esc_html__( 'Single Column', 'rubenz' ),
				),
				'render_type'     => 'template',
				'desktop_default' => 4,
				'tablet_default'  => 6,
				'mobile_default'  => 12,
			)
		);

		/**
		 * Space Between
		 */
		$this->add_responsive_control(
			'space_between',
			array(
				'label'           => esc_html__( 'Space Between', 'rubenz' ),
				'type'            => Controls_Manager::SLIDER,
				'range'           => array(
					'px' => array(
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					),
				),
				'devices'         => array( 'desktop', 'tablet', 'mobile' ),
				'desktop_default' => array(
					'size' => 80,
				),
				'tablet_default'  => array(
					'size' => 30,
				),
				'mobile_default'  => array(
					'size' => 15,
				),
				'selectors'       => array(
					'{{WRAPPER}}'                     => 'overflow: hidden;',
					'{{WRAPPER}} .grid'               => 'margin: calc(-{{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item'         => 'padding: calc({{SIZE}}{{UNIT}} / 2) calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid__item_caption' => 'padding: calc({{SIZE}}{{UNIT}} / 2 - 1em) calc({{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: {{SIZE}}{{UNIT}};',
					'(tablet){{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: 0;',
					'(mobile){{WRAPPER}} .grid_fancy .grid__item:nth-child(3)' => 'margin-top: 0;',
				),
				'render_type'     => 'template',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings    = $this->get_settings_for_display();
		$col_desktop = 'grid__item_desktop-' . $settings['columns'];
		$col_tablet  = 'grid__item_tablet-' . $settings['columns_tablet'];
		$col_mobile  = 'grid__item_mobile-' . $settings['columns_mobile'];
		$lightbox    = $settings['lightbox'];

		$this->add_render_attribute(
			'section',
			array(
				'class'                    => array( 'grid', 'js-grid' ),
				'data-grid-columns'        => 12 / $settings['columns'],
				'data-grid-columns-tablet' => 12 / $settings['columns_tablet'],
				'data-grid-columns-mobile' => 12 / $settings['columns_mobile'],
			)
		);

		$this->add_render_attribute(
			'sizerAtts',
			array(
				'class' => array( 'grid__sizer', 'js-grid__sizer', $col_desktop, $col_tablet, $col_mobile ),
			)
		);

		if ( $settings['enable_fancy'] ) {
			$this->add_render_attribute(
				'section',
				array(
					'class' => array( 'grid_fancy', 'js-grid' ),
				)
			);
		}
		?>
		<?php if ( ! empty( $settings['gallery'] ) ) : ?>
			<div <?php echo $this->get_render_attribute_string( 'section' ); ?>>
				<div <?php echo $this->get_render_attribute_string( 'sizerAtts' ); ?>></div>
				<?php foreach ( $settings['gallery'] as $image ) : ?>
					<?php
						$title         = get_the_title( $image['id'] );
						$class_caption = '';

					if ( $settings['enable_captions'] && ! empty( $title ) ) {
						$class_caption = 'grid__item_caption';
					}

						$this->add_render_attribute(
							'itemAtts',
							array(
								'class' => array( 'grid__item', 'js-grid__item', $col_desktop, $col_tablet, $col_mobile, $class_caption ),
							),
							true,
							true
						);

					?>
					<div <?php echo $this->get_render_attribute_string( 'itemAtts' ); ?>>
						<?php

						if ( $lightbox ) {
							$this->add_render_attribute(
								'lightboxAtts',
								array(
									'class' => 'grid__item-link',
									'href'  => $image['url'],
									'data-elementor-open-lightbox' => 'true',
									'data-elementor-lightbox-slideshow' => $this->get_id(),
								),
								true,
								true
							);

							?>
							<a <?php echo $this->get_render_attribute_string( 'lightboxAtts' ); ?>>
							<?php } ?>
								<div class="figure-image">
									<?php
										arts_the_lazy_image(
											array(
												'id'    => $image['id'],
												'type'  => 'image',
												'class' => array(
													'wrapper' => array( 'figure-image__wrapper-img' ),
												),
											)
										);
									?>
									<?php if ( $lightbox ) : ?>
										<div class="grid__item-icon">
											<div class="grid__item-icon-symbol material-icons">search</div>
										</div>
										<div class="grid__item-overlay"></div>
									<?php endif; ?>
									<?php if ( $settings['enable_captions'] && ! empty( $title ) ) : ?>
										<h5><?php echo $title; ?></h5>
									<?php endif; ?>
								</div>
							<?php if ( $lightbox ) : ?>
							</a>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php
	}
}
