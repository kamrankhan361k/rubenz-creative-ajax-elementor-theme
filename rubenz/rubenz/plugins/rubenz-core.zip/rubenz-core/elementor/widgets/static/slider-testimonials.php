<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Slider_Testimonials extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-slider-testimonials';
	}

	public function get_title() {
		return esc_html__( 'Slider Testimonials', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions'        => array( 'widgetType' => $name ),
			'fields'            => array(),
			'integration-class' => 'WPML_Rubenz_Elementor_Slider_Testimonials',
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'author',
			array(
				'label'       => esc_html__( 'Author', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Author...', 'rubenz' ),
			)
		);

		$repeater->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Author Avatar', 'rubenz' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			)
		);

		$repeater->add_control(
			'text',
			array(
				'label'       => esc_html__( 'Text', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => esc_html__( 'Text...', 'rubenz' ),
			)
		);

		$this->add_control(
			'testimonials',
			array(
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ author }}}',
				'prevent_empty' => false,
			)
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings  = $this->get_settings_for_display();
		$num_items = count( $settings['testimonials'] );
		?>
		<div class="slider-testimonials js-slider-testimonials">
			<?php if ( $settings['testimonials'] ) : ?>
				<div class="slider slider-header-testimonials swiper swiper-container js-slider-testimonials__header">
					<div class="swiper-wrapper">
						<?php foreach ( $settings['testimonials'] as $index => $item ) : ?>
							<?php
								$authorKey = $this->get_repeater_setting_key( 'author', 'testimonials', $index );
								$this->add_inline_editing_attributes( $authorKey );
							?>
							<div class="swiper-slide slider-header-testimonials__slide">
								<span <?php echo $this->get_render_attribute_string( $authorKey ); ?>><?php echo $item['author']; ?></span>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<!-- - slider header testimonials -->
			<?php endif; ?>
			<?php if ( $settings['testimonials'] ) : ?>
				<div class="slider swiper swiper-container js-slider-testimonials__items">
					<div class="swiper-wrapper">
						<?php foreach ( $settings['testimonials'] as $index => $item ) : ?>
							<div class="swiper-slide slider-testimonials__slide">
								<?php if ( ! empty( $item['image']['url'] ) ) : ?>
									<div class="slider-testimonials__wrapper-avatar">
										<?php
											arts_the_lazy_image(
												array(
													'id' => $item['image']['id'],
													'class' => array(
														'wrapper' => array(),
														'image' => array( 'swiper-lazy' ),
													),
												)
											);
										?>
									</div>
								<?php endif; ?>
								<?php if ( ! empty( $item['text'] ) ) : ?>
									<?php
										$textKey = $this->get_repeater_setting_key( 'text', 'testimonials', $index );
										$this->add_inline_editing_attributes( $textKey );
									?>
									<div class="slider-testimonials__wrapper-text">
										<blockquote <?php echo $this->get_render_attribute_string( $textKey ); ?>><?php echo $item['text']; ?></blockquote>
									</div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
					<?php if ( $num_items > 1 ) : ?>
						<div class="slider-testimonials__footer">
							<div class="slider__dots js-slider-testimonials__dots">
								<div class="slider__dot slider__dot_active"></div>
								<div class="slider__dot"></div>
								<div class="slider__dot"></div>
								<div class="slider__dot"></div>
							</div>
						</div>
					<?php endif; ?>
				</div>
				<!-- - slider testimonials -->
			<?php endif; ?>
		</div>
		<?php
	}
}
