<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Rubenz_Widget_Call_To_Action extends Rubenz_Widget_Base {
	protected static $_instance = null;

	public function get_name() {
		return 'rubenz-widget-call-to-action';
	}

	public function get_title() {
		return esc_html__( 'Call to Action', 'rubenz' );
	}

	public function get_icon() {
		return 'eicon-plug';
	}

	public function get_categories() {
		return array( 'rubenz-static' );
	}

	public function wpml_widgets_to_translate_filter( $widgets ) {
		$name  = $this->get_name();
		$title = $this->get_title();

		$widgets[ $name ] = array(
			'conditions' => array( 'widgetType' => $name ),
			'fields'     => array(
				array(
					'field'       => 'heading',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Heading', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'text',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Text', 'rubenz' ) ),
					'editor_type' => 'AREA',
				),
				array(
					'field'       => 'button_title',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Title', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
				array(
					'field'       => 'button_link',
					'type'        => sprintf( '<strong>%1$s</strong><br>%2$s', $title, esc_html__( 'Button Link', 'rubenz' ) ),
					'editor_type' => 'LINE',
				),
			),
		);

		return $widgets;
	}

	public function add_wpml_support() {
		add_filter( 'wpml_elementor_widgets_to_translate', array( $this, 'wpml_widgets_to_translate_filter' ) );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_decoration_line',
			array(
				'label'   => esc_html__( 'Show Line Decoration', 'rubenz' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'       => esc_html__( 'Heading', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Heading...', 'rubenz' ),
			)
		);

		$this->add_control(
			'text',
			array(
				'label'   => esc_html__( 'Text', 'rubenz' ),
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 10,
				'default' => esc_html__( 'Heading details...', 'rubenz' ),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			array(
				'label' => esc_html__( 'Button', 'rubenz' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'button_title',
			array(
				'label'       => esc_html__( 'Title', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Button', 'rubenz' ),
			)
		);

		$this->add_control(
			'button_link',
			array(
				'label'         => esc_html__( 'Link', 'rubenz' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_html__( 'https://...', 'rubenz' ),
				'show_external' => true,
				'default'       => array(
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				),
			)
		);

		$this->add_control(
			'button_style',
			array(
				'label'       => esc_html__( 'Style', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_bordered' => esc_html__( 'Bordered', 'rubenz' ),
					'button_solid'    => esc_html__( 'Solid', 'rubenz' ),
				),
				'default'     => 'button_solid',
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'       => esc_html__( 'Color', 'rubenz' ),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT,
				'options'     => array(
					'button_dark'  => esc_html__( 'Dark', 'rubenz' ),
					'button_light' => esc_html__( 'Light', 'rubenz' ),
					'button_black' => esc_html__( 'Black', 'rubenz' ),
					'button_white' => esc_html__( 'White', 'rubenz' ),
				),
				'default'     => 'button_dark',
			)
		);

		$this->add_control(
			'button_shadow',
			array(
				'label'        => esc_html__( 'Shadow', 'rubenz' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'button_shadow',
				'return_value' => 'button_shadow',
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_inline_editing_attributes( 'heading' );
		$this->add_inline_editing_attributes( 'text' );
		$this->add_inline_editing_attributes( 'button_title' );
		?>
		<div class="section-cta container">
			<header class="row section__header">
				<div class="col">
					<?php if ( $settings['show_decoration_line'] ) : ?>
						<div class="section-cta__headline"></div>
					<?php endif; ?>
					<?php if ( ! empty( $settings['heading'] ) ) : ?>
						<h2 <?php echo $this->get_render_attribute_string( 'heading' ); ?>><?php echo $settings['heading']; ?></h2>
					<?php endif; ?>
					<?php if ( ! empty( $settings['text'] ) ) : ?>
						<p <?php echo $this->get_render_attribute_string( 'text' ); ?>><?php echo $settings['text']; ?></p>
					<?php endif; ?>
				</div>
			</header>
			<?php if ( ! empty( $settings['button_title'] ) ) : ?>
				<div class="row section-cta__wrapper-button">
					<div class="col">
						<?php
							$this->add_render_attribute(
								'button',
								array(
									'class' => array( 'button', $settings['button_style'], $settings['button_color'], $settings['button_shadow'] ),
									'href'  => $settings['button_link']['url'],
								)
							);

						if ( $settings['button_link']['is_external'] ) {
							$this->add_render_attribute( 'button', 'target', '_blank' );
						}

						if ( $settings['button_link']['nofollow'] ) {
							$this->add_render_attribute( 'button', 'rel', 'nofollow' );
						}
						?>
						<a <?php echo $this->get_render_attribute_string( 'button' ); ?>><span <?php echo $this->get_render_attribute_string( 'button_title' ); ?>><?php echo $settings['button_title']; ?></span></a>
					</div>
				</div>
				<!-- - button-->
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {
		?>
		<#
			view.addInlineEditingAttributes( 'heading' );
			view.addInlineEditingAttributes( 'text' );
			view.addInlineEditingAttributes( 'button_title' );
		#>
		<div class="section-cta container">
			<header class="row section__header">
				<div class="col">
					<# if ( settings.show_decoration_line ) { #>
						<div class="section-cta__headline"></div>
					<# } #>
					<# if ( settings.heading ) { #>
						<h2 {{{ view.getRenderAttributeString( 'heading' ) }}}>{{{ settings.heading }}}</h2>
					<# } #>
					<# if ( settings.text ) { #>
						<p {{{ view.getRenderAttributeString( 'text' ) }}}>{{{ settings.text }}}</p>
					<# } #>
				</div>
			</header>
			<# if ( settings.button_title ) { #>
				<div class="row section-cta__wrapper-button">
					<div class="col">
						<#
						view.addRenderAttribute(
								'button', {
									'class': [ 'button', settings.button_style, settings.button_color, settings.button_shadow ],
									'href': settings.button_link.url,
								}
							);

						if ( settings.button_link.is_external ) {
							view.addRenderAttribute( 'button', 'target', '_blank' );
						}

						if ( settings.button_link.nofollow ) {
							view.addRenderAttribute( 'button', 'rel', 'nofollow' );
						}
						#>
						<a {{{ view.getRenderAttributeString( 'button' ) }}}><span {{{ view.getRenderAttributeString( 'button_title' ) }}}>{{{ settings.button_title }}}</span></a>
					</div>
				</div>
				<!-- - button-->
			<# } #>
		</div>
		<?php
	}
}
