<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'init', 'arts_register_taxonomies' );
function arts_register_taxonomies() {

	/**
	 * Portfolio Category
	 */
	register_taxonomy(
		'arts_portfolio_category',
		array( 'arts_portfolio_item' ),
		array(
			'labels'            => array(
				'name'                       => _x( 'Portfolio Categories', 'taxonomy general name', 'rubenz' ),
				'singular_name'              => _x( 'Portfolio Category', 'taxonomy singular name', 'rubenz' ),
				'search_items'               => __( 'Search Portfolio Categories', 'rubenz' ),
				'all_items'                  => __( 'All Portfolio Categories', 'rubenz' ),
				'parent_item'                => __( 'Parent Portfolio Category', 'rubenz' ),
				'parent_item_colon'          => __( 'Parent Portfolio Category:', 'rubenz' ),
				'edit_item'                  => __( 'Edit Portfolio Category', 'rubenz' ),
				'update_item'                => __( 'Update Portfolio Category', 'rubenz' ),
				'add_new_item'               => __( 'Add New Portfolio Category', 'rubenz' ),
				'new_item_name'              => __( 'New Portfolio Category', 'rubenz' ),
				'separate_items_with_commas' => __( 'Separate portfolio categories with commas', 'rubenz' ),
				'add_or_remove_items'        => __( 'Add or remove writers', 'rubenz' ),
				'choose_from_most_used'      => __( 'Choose from the most used portfolio categories', 'rubenz' ),
				'not_found'                  => __( 'No portfolio categories found.', 'rubenz' ),
				'menu_name'                  => __( 'Portfolio Categories', 'rubenz' ),
			),
			'public'            => true,
			'hierarchical'      => false,
			'show_admin_column' => true,
			'query_var'         => true,
		)
	);

}

