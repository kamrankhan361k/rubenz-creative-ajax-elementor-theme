<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'widgets_init', 'arts_register_widgets' );
function arts_register_widgets() {

	$widgets = array(
		'logo'      => 'Rubenz_Widget_Logo',
		'social'    => 'Rubenz_Widget_Social',
		'copyright' => 'Rubenz_Widget_Copyright',
	);

	foreach ( $widgets as $index => $value ) {

		require_once __DIR__ . '/widgets/' . sanitize_key( $index ) . '-widget.php';
		register_widget( $value );
	}

}
